package com.vswitch.tunnel.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.vswitch.tunnel.R
import com.vswitch.tunnel.battery.BatteryOptimizationManager
import com.vswitch.tunnel.ui.MainActivity
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer

class MyVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var isRunning = false
    private var isBatterySaverEnabled = false

    // JNI Native Socket Bridge
    private val socketBridge = UnixSocketBridge()
    private val grpcClient = GrpcTunnelClient("sg1.vswitch-tunnel.net", 50051)
    private lateinit var batteryManager: BatteryOptimizationManager

    private val connectivityCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            super.onAvailable(network)
            Log.i(TAG, "Network switched/available -> Triggering dynamic Auto-Reconnect")
            serviceScope.launch {
                handleNetworkSwitch(network)
            }
        }

        override fun onLost(network: Network) {
            super.onLost(network)
            Log.w(TAG, "Active network lost -> Entering Reconnecting state")
        }
    }

    override fun onCreate() {
        super.onCreate()
        batteryManager = BatteryOptimizationManager(this)
        batteryManager.init()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_DISCONNECT) {
            stopTunnelEngine()
            stopSelf()
            return START_NOT_STICKY
        }

        val serverHost = intent?.getStringExtra(EXTRA_SERVER_HOST) ?: "sg1.vswitch-tunnel.net"
        val serverPort = intent?.getIntExtra(EXTRA_SERVER_PORT, 50051) ?: 50051
        isBatterySaverEnabled = intent?.getBooleanExtra(EXTRA_BATTERY_SAVER, false) ?: false

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification("VPN Tunnel Aktif ($serverHost)"))
        registerNetworkCallback()
        startTunnelEngine(serverHost, serverPort)
        return START_STICKY
    }

    private fun startTunnelEngine(host: String, port: Int) {
        if (isRunning) return
        isRunning = true

        serviceScope.launch {
            try {
                // 1. Configure TUN Interface
                val builder = Builder()
                    .setSession("vSwitch-gRPC-Tunnel")
                    .setMtu(1500)
                    .addAddress("10.0.0.10", 24)
                    .addRoute("0.0.0.0", 0)
                    .addDnsServer("1.1.1.1")
                    .addDnsServer("8.8.8.8")
                    .setBlocking(false)

                vpnInterface = builder.establish() ?: run {
                    Log.e(TAG, "Gagal menginisialisasi TUN interface")
                    return@launch
                }
                val tunFd = vpnInterface!!.fileDescriptor

                // 2. Connect Abstract Domain Socket (@vswitch.sock) via C++ JNI
                val socketConnected = socketBridge.connectAbstractSocket("vswitch.sock")
                Log.i(TAG, "Abstract Domain Socket @vswitch.sock terhubung: $socketConnected")

                // 3. Connect gRPC Bi-Directional Stream
                grpcClient.connectStream()

                // 4. Launch Bi-directional Packet Worker Coroutines
                val jobOutbound = launch { readTunAndForward(tunFd) }
                val jobInbound = launch { receiveAndWriteTun(tunFd) }

                jobOutbound.join()
                jobInbound.join()

            } catch (e: Exception) {
                Log.e(TAG, "Tunnel failure: ${e.message}", e)
                performAutoReconnect(host, port)
            }
        }
    }

    private suspend fun readTunAndForward(tunFd: java.io.FileDescriptor) = withContext(Dispatchers.IO) {
        val inStream = FileInputStream(tunFd)
        val buffer = ByteArray(2048)

        while (isRunning && isActive) {
            val bytesRead = inStream.read(buffer)
            if (bytesRead > 0) {
                val packet = buffer.copyOf(bytesRead)
                // Forward via Abstract Domain Socket (local) or gRPC Stream (remote)
                if (socketBridge.isConnected()) {
                    socketBridge.sendFrame(packet)
                } else {
                    grpcClient.sendFrame(packet)
                }

                // Battery Saver Mode: Adaptive micro-pause for small batches
                if (isBatterySaverEnabled && bytesRead < 256) {
                    delay(2)
                }
            }
        }
    }

    private suspend fun receiveAndWriteTun(tunFd: java.io.FileDescriptor) = withContext(Dispatchers.IO) {
        val outStream = FileOutputStream(tunFd)

        while (isRunning && isActive) {
            val inboundFrame = if (socketBridge.isConnected()) {
                socketBridge.readFrame()
            } else {
                grpcClient.pollInboundFrame()
            }

            if (inboundFrame != null && inboundFrame.isNotEmpty()) {
                outStream.write(inboundFrame)
            }
        }
    }

    private suspend fun handleNetworkSwitch(network: Network) {
        Log.i(TAG, "Seamless Handover: Switching transport routes...")
        // Protect socket descriptor from being routed back to VPN interface
        protect(grpcClient.getSocketFd())
        grpcClient.renegotiateStream()
    }

    private fun performAutoReconnect(host: String, port: Int) {
        serviceScope.launch {
            delay(2000)
            if (isRunning) {
                Log.i(TAG, "Executing Auto-Reconnect backoff...")
                startTunnelEngine(host, port)
            }
        }
    }

    private fun registerNetworkCallback() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        cm.registerNetworkCallback(request, connectivityCallback)
    }

    private fun stopTunnelEngine() {
        isRunning = false
        serviceScope.cancel()
        socketBridge.close()
        grpcClient.disconnect()
        try {
            vpnInterface?.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error closing vpn interface", e)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "vSwitch VPN Status",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Status koneksi tunneling vSwitch VPN"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(contentText: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val disconnectIntent = PendingIntent.getService(
            this, 1,
            Intent(this, MyVpnService::class.java).apply { action = ACTION_DISCONNECT },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("vSwitch gRPC Tunnel")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Putuskan", disconnectIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopTunnelEngine()
        batteryManager.destroy()
    }

    companion object {
        const val TAG = "vSwitchVpnService"
        const val CHANNEL_ID = "vswitch_vpn_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_DISCONNECT = "com.vswitch.tunnel.DISCONNECT"
        const val EXTRA_SERVER_HOST = "EXTRA_SERVER_HOST"
        const val EXTRA_SERVER_PORT = "EXTRA_SERVER_PORT"
        const val EXTRA_BATTERY_SAVER = "EXTRA_BATTERY_SAVER"
    }
}
