package com.vswitch.tunnel.ui

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial
import com.vswitch.tunnel.R
import com.vswitch.tunnel.service.MyVpnService

class MainActivity : AppCompatActivity() {

    private var isVpnConnected = false
    private lateinit var btnToggle: Button
    private lateinit var txtStatus: TextView
    private lateinit var switchBattery: SwitchMaterial

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            startVpnService()
        } else {
            Toast.makeText(this, "Izin VPN diperlukan untuk mengamankan koneksi", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnToggle = findViewById(R.id.btnToggleVpn)
        txtStatus = findViewById(R.id.txtVpnStatus)
        switchBattery = findViewById(R.id.switchBatterySaver)

        btnToggle.setOnClickListener {
            if (isVpnConnected) {
                stopVpnService()
            } else {
                prepareAndStartVpn()
            }
        }
    }

    private fun prepareAndStartVpn() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            vpnPermissionLauncher.launch(intent)
        } else {
            startVpnService()
        }
    }

    private fun startVpnService() {
        val intent = Intent(this, MyVpnService::class.java).apply {
            putExtra(MyVpnService.EXTRA_SERVER_HOST, "sg1.vswitch-tunnel.net")
            putExtra(MyVpnService.EXTRA_SERVER_PORT, 50051)
            putExtra(MyVpnService.EXTRA_BATTERY_SAVER, switchBattery.isChecked)
        }
        startService(intent)
        isVpnConnected = true
        updateUiState()
    }

    private fun stopVpnService() {
        val intent = Intent(this, MyVpnService::class.java).apply {
            action = MyVpnService.ACTION_DISCONNECT
        }
        startService(intent)
        isVpnConnected = false
        updateUiState()
    }

    private fun updateUiState() {
        if (isVpnConnected) {
            btnToggle.text = "PUTUSKAN TUNNEL"
            btnToggle.setBackgroundColor(getColor(R.color.vpn_active))
            txtStatus.text = "Status: TERHUBUNG & TERENKRIPSI (gRPC ↔ @vswitch.sock)"
        } else {
            btnToggle.text = "HUBUNGKAN SEKARANG"
            btnToggle.setBackgroundColor(getColor(R.color.vpn_inactive))
            txtStatus.text = "Status: TERPUTUS"
        }
    }
}
