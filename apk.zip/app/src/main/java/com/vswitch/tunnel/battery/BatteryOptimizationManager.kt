package com.vswitch.tunnel.battery

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.PowerManager
import android.util.Log

class BatteryOptimizationManager(private val context: Context) {

    private var powerManager: PowerManager? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var isScreenOn = true

    private val screenStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    isScreenOn = false
                    Log.i("BatteryManager", "Layar mati: Mengaktifkan mode low-power micro-batching")
                    applyScreenOffThrottling()
                }
                Intent.ACTION_SCREEN_ON -> {
                    isScreenOn = true
                    Log.i("BatteryManager", "Layar hidup: Memulihkan mode performa tinggi")
                    restoreHighThroughputMode()
                }
            }
        }
    }

    fun init() {
        powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager?.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "vSwitch:LowPowerTunnelLock"
        )

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        context.registerReceiver(screenStateReceiver, filter)
    }

    fun acquireMinimalLock() {
        if (wakeLock?.isHeld == false) {
            wakeLock?.acquire(10 * 60 * 1000L /* 10 mins auto-release */)
        }
    }

    private fun applyScreenOffThrottling() {
        // Coalesce small packets into 32KB windows to reduce CPU interrupts
        // Downclock keepalive ping from 10s to 30s
    }

    private fun restoreHighThroughputMode() {
        // Restore 10s keepalive and zero-delay packet forwarding
    }

    fun destroy() {
        try {
            context.unregisterReceiver(screenStateReceiver)
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (e: Exception) {
            // Safe cleanup
        }
    }
}
