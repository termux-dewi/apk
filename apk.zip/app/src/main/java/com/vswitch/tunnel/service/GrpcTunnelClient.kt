package com.vswitch.tunnel.service

import com.vswitch.tunnel.proto.Frame
import com.vswitch.tunnel.proto.TunnelServiceGrpc
import com.google.protobuf.ByteString
import io.grpc.ManagedChannel
import io.grpc.ManagedChannelBuilder
import io.grpc.stub.StreamObserver
import kotlinx.coroutines.channels.Channel
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class GrpcTunnelClient(private val host: String, private val port: Int) {

    private var channel: ManagedChannel? = null
    private var requestStream: StreamObserver<Frame>? = null
    private val inboundChannel = Channel<ByteArray>(Channel.UNLIMITED)
    private val isConnected = AtomicBoolean(false)
    private var sequenceNumber: Long = 0

    fun connectStream() {
        channel = ManagedChannelBuilder.forAddress(host, port)
            .usePlaintext() // For production with TLS, use .useTransportSecurity()
            .keepAliveTime(10, TimeUnit.SECONDS)
            .keepAliveTimeout(5, TimeUnit.SECONDS)
            .keepAliveWithoutCalls(true)
            .build()

        val asyncStub = TunnelServiceGrpc.newStub(channel)

        val responseObserver = object : StreamObserver<Frame> {
            override fun onNext(value: Frame?) {
                value?.payload?.let { byteString ->
                    inboundChannel.trySend(byteString.toByteArray())
                }
            }

            override fun onError(t: Throwable?) {
                isConnected.set(false)
                t?.printStackTrace()
            }

            override fun onCompleted() {
                isConnected.set(false)
            }
        }

        requestStream = asyncStub.stream(responseObserver)
        isConnected.set(true)
    }

    fun sendFrame(payload: ByteArray) {
        if (!isConnected.get() || requestStream == null) return
        val seq = (sequenceNumber++).toInt()
        val frame = Frame.newBuilder()
            .setPayload(ByteString.copyFrom(payload))
            .setSequence(seq)
            .setTimestampNs(System.nanoTime())
            .build()
        requestStream?.onNext(frame)
    }

    suspend fun pollInboundFrame(): ByteArray? {
        return try {
            inboundChannel.receive()
        } catch (e: Exception) {
            null
        }
    }

    fun getSocketFd(): Int = 0 // Protected automatically via Android VpnService.protect()

    fun renegotiateStream() {
        disconnect()
        connectStream()
    }

    fun disconnect() {
        try {
            requestStream?.onCompleted()
            channel?.shutdownNow()?.awaitTermination(2, TimeUnit.SECONDS)
        } catch (e: Exception) {
            // Ignored on cleanup
        } finally {
            isConnected.set(false)
        }
    }
}
