package com.vswitch.tunnel.service

import android.util.Log

/**
 * JNI wrapper for connecting directly to Linux Abstract Namespace Sockets (@vswitch.sock)
 * Provides ultra-low latency, zero-copy packet exchange with the local vSwitch daemon.
 */
class UnixSocketBridge {

    companion object {
        init {
            try {
                System.loadLibrary("abstract_bridge")
                Log.i("UnixSocketBridge", "Native library libabstract_bridge.so loaded successfully")
            } catch (e: UnsatisfiedLinkError) {
                Log.e("UnixSocketBridge", "Failed to load native library", e)
            }
        }
    }

    private var connected = false

    fun connectAbstractSocket(socketName: String): Boolean {
        connected = nativeConnectAbstract(socketName)
        return connected
    }

    fun sendFrame(frame: ByteArray): Boolean {
        if (!connected) return false
        return nativeSendFrame(frame)
    }

    fun readFrame(): ByteArray? {
        if (!connected) return null
        return nativeReadFrame()
    }

    fun close() {
        if (connected) {
            nativeClose()
            connected = false
        }
    }

    fun isConnected(): Boolean = connected

    // Native JNI functions implemented in C++ (AbstractSocketBridge.cpp)
    private external fun nativeConnectAbstract(socketName: String): Boolean
    private external fun nativeSendFrame(frame: ByteArray): Boolean
    private external fun nativeReadFrame(): ByteArray?
    private external fun nativeClose()
}
