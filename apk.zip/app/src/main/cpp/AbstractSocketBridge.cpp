#include <jni.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <android/log.h>
#include <string.h>
#include <errno.h>
#include <arpa/inet.h>

#define TAG "AbstractSocketBridge"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static int g_socket_fd = -1;

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vswitch_tunnel_service_UnixSocketBridge_nativeConnectAbstract(
        JNIEnv *env, jobject thiz, jstring socketName) {
    
    const char *name = env->GetStringUTFChars(socketName, nullptr);
    if (!name) return JNI_FALSE;

    g_socket_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (g_socket_fd < 0) {
        LOGE("Gagal membuat socket AF_UNIX: %s", strerror(errno));
        env->ReleaseStringUTFChars(socketName, name);
        return JNI_FALSE;
    }

    // Set 2MB buffer for high-throughput zero-drop
    int bufSize = 2 * 1024 * 1024;
    setsockopt(g_socket_fd, SOL_SOCKET, SO_RCVBUF, &bufSize, sizeof(bufSize));
    setsockopt(g_socket_fd, SOL_SOCKET, SO_SNDBUF, &bufSize, sizeof(bufSize));

    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;

    // First byte is null '\0' for Linux Abstract Namespace Socket (@name)
    addr.sun_path[0] = '\0';
    strncpy(addr.sun_path + 1, name, sizeof(addr.sun_path) - 2);

    socklen_t addrLen = sizeof(sa_family_t) + 1 + strlen(name);

    if (connect(g_socket_fd, (struct sockaddr *)&addr, addrLen) < 0) {
        LOGE("Gagal terhubung ke abstract socket @%s: %s", name, strerror(errno));
        close(g_socket_fd);
        g_socket_fd = -1;
        env->ReleaseStringUTFChars(socketName, name);
        return JNI_FALSE;
    }

    LOGI("Berhasil terhubung ke Abstract Domain Socket: @%s (fd=%d)", name, g_socket_fd);
    env->ReleaseStringUTFChars(socketName, name);
    return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vswitch_tunnel_service_UnixSocketBridge_nativeSendFrame(
        JNIEnv *env, jobject thiz, jbyteArray frame) {
    if (g_socket_fd < 0) return JNI_FALSE;

    jsize len = env->GetArrayLength(frame);
    jbyte *buf = env->GetByteArrayElements(frame, nullptr);

    // Write uint32 Length Prefix + Frame Payload (matching Go ProcessStream format)
    uint32_t netLen = htonl((uint32_t)len);
    ssize_t w1 = write(g_socket_fd, &netLen, 4);
    ssize_t w2 = write(g_socket_fd, buf, len);

    env->ReleaseByteArrayElements(frame, buf, JNI_ABORT);
    return (w1 == 4 && w2 == len) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_vswitch_tunnel_service_UnixSocketBridge_nativeReadFrame(
        JNIEnv *env, jobject thiz) {
    if (g_socket_fd < 0) return nullptr;

    uint32_t netLen = 0;
    ssize_t n = read(g_socket_fd, &netLen, 4);
    if (n != 4) return nullptr;

    uint32_t frameLen = ntohl(netLen);
    if (frameLen < 14 || frameLen > 4096) return nullptr;

    jbyteArray result = env->NewByteArray(frameLen);
    jbyte *buf = env->GetByteArrayElements(result, nullptr);
    ssize_t bytesRead = read(g_socket_fd, buf, frameLen);
    env->ReleaseByteArrayElements(result, buf, 0);

    if (bytesRead != (ssize_t)frameLen) {
        return nullptr;
    }
    return result;
}

extern "C" JNIEXPORT void JNICALL
Java_com_vswitch_tunnel_service_UnixSocketBridge_nativeClose(
        JNIEnv *env, jobject thiz) {
    if (g_socket_fd >= 0) {
        close(g_socket_fd);
        g_socket_fd = -1;
        LOGI("Abstract domain socket ditutup");
    }
}
