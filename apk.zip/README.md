# vSwitch Android VPN Client (gRPC ↔ Abstract Domain Socket ↔ Android TUN)

Aplikasi client VPN Android berperforma tinggi dengan pipeline:
```
[ Aplikasi Android ] 
       │
       ▼ (TUN Interface / IP Packets)
[ MyVpnService.kt ]
       │
       ▼ (UnixSocketBridge JNI)
[ Abstract Domain Socket (@vswitch.sock) ]
       │
       ▼ (Low-Latency Bi-Directional Stream)
[ gRPC Gateway / Remote Server ]
```

## Persyaratan Sistem (Prerequisites)
1. **Android Studio**: Jellyfish (2023.3.1) / Koala / Ladybug atau versi terbaru.
2. **Android SDK**: API 35 (Android 15) dengan Min SDK 26 (Android 8.0 Oreo).
3. **NDK & CMake**: NDK r26c+ dan CMake 3.22.1 terpasang via SDK Manager.
4. **JDK**: Java 17 atau Java 21.

---

## Cara Kompilasi & Build APK

### Opsi 1: Menggunakan Android Studio (GUI)
1. Ekstrak file ZIP proyek ini ke folder komputer Anda.
2. Buka **Android Studio** -> Pilih **File > Open** -> Arahkan ke folder hasil ekstrak.
3. Tunggu hingga proses **Gradle Sync** selesai mengunduh dependensi (gRPC, Protobuf, AndroidX).
4. Klik menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Setelah build selesai, notifikasi pop-up akan muncul dengan tombol **locate** untuk membuka file `app-debug.apk`.

### Opsi 2: Menggunakan Terminal / CLI (Gradle Wrapper)
```bash
# 1. Masuk ke direktori project
cd vswitch-vpn-android

# 2. Berikan izin eksekusi gradlew (Linux/macOS)
chmod +x gradlew

# 3. Kompilasi Debug APK
./gradlew assembleDebug

# 4. Lokasi APK yang dihasilkan:
# app/build/outputs/apk/debug/app-debug.apk

# 5. Install langsung ke HP Android via ADB:
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Opsi 3: Build Release APK (Production Signed)
```bash
./gradlew assembleRelease
```

---

## Fitur Utama
- **Pipeline gRPC ↔ Abstract Socket ↔ Android TUN**: Bypass bottleneck userspace dengan zero-drop buffering 2MB.
- **Auto-Reconnect Real-Time**: Deteksi otomatis pergantian jaringan (Wi-Fi 6 ↔ 5G ↔ 4G LTE) tanpa kebocoran IP (*failover protect*).
- **Mode Hemat Baterai**: Micro-batching adaptif dan downclocking keepalive saat layar mati.
- **End-to-End Encryption**: Zero-Knowledge token frame payload.
