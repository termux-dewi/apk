@rem Gradle wrapper script
@if "%DEBUG%" == "" @echo off
"%JAVA_EXE%" -Dorg.gradle.appname=gradlew -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*
